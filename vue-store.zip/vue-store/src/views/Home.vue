<template>
    <v-container>
      <v-text-field v-model="search" label="Buscar productos"></v-text-field>
      <v-row>
        <v-col v-for="product in filteredProducts" :key="product.id" cols="12" md="4">
          <v-card>
            <v-card-title>{{ product.name }}</v-card-title>
            <v-card-subtitle>{{ product.category }}</v-card-subtitle>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script lang="ts">
  import { defineComponent, onMounted, ref, computed } from 'vue';
  import axios from 'axios';
  
  export default defineComponent({
    setup() {
      const products = ref([]);
      const search = ref('');
  
      onMounted(async () => {
        const response = await axios.get('https://api.takeit.ciph3r.co/products');
        products.value = response.data;
      });
  
      const filteredProducts = computed(() => {
        return products.value.filter(product =>
          product.name.toLowerCase().includes(search.value.toLowerCase()) ||
          product.category.toLowerCase().includes(search.value.toLowerCase())
        );
      });
  
      return { search, filteredProducts };
    },
  });
  </script>
  