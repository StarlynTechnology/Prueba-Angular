<template>
    <v-container>
      <v-form>
        <v-text-field label="Email" v-model="email" />
        <v-text-field label="Password" type="password" v-model="password" />
        <v-btn @click="login">Login</v-btn>
      </v-form>
    </v-container>
  </template>
  
  <script lang="ts">
  import { defineComponent, ref } from 'vue';
  
  export default defineComponent({
    setup() {
      const email = ref('');
      const password = ref('');
  
      const login = () => {
        console.log('Login attempt with:', email.value, password.value);
      };
  
      return { email, password, login };
    },
  });
  </script>
  