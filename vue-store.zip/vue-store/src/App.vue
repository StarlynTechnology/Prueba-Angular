<template>
  <v-app>
    <!-- Barra de navegación -->
    <v-app-bar app>
      <v-toolbar-title>Vue Store</v-toolbar-title>
      <v-spacer></v-spacer>
      <router-link to="/login">
        <v-btn text>Login</v-btn>
      </router-link>
      <router-link to="/register">
        <v-btn text>Register</v-btn>
      </router-link>
    </v-app-bar>

    <!-- Contenido principal -->
    <v-main>
      <v-container>
        <router-view />
      </v-container>
    </v-main>

    <!-- Pie de página -->
    <v-footer app>
      <v-col class="text-center">© 2024 Vue Store</v-col>
    </v-footer>
  </v-app>
</template>

<script lang="ts">
export default {};
</script>

<style scoped>
/* Opcional: estilos personalizados */
.v-footer {
  background-color: #6200ea;
  color: white;
}
</style>
