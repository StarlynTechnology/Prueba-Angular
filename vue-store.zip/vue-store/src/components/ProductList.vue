<template>
    <v-container>
      <v-text-field label="Search" v-model="search" @input="filterProducts" />
      <v-select :items="categories" label="Category" v-model="selectedCategory" @change="filterProducts" />
  
      <v-row>
        <v-col cols="12" sm="6" md="4" v-for="product in filteredProducts" :key="product.id">
          <v-card>
            <v-card-title>{{ product.name }}</v-card-title>
            <v-card-subtitle>{{ product.category }}</v-card-subtitle>
            <v-card-actions>
              <v-btn @click="addToCart(product)">Add to Cart</v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script lang="ts">
  import { defineComponent, ref } from 'vue';
  import axios from 'axios';
  
  export default defineComponent({
    name: 'ProductList',
    setup() {
      const products = ref([]);
      const categories = ref([]);
      const search = ref('');
      const selectedCategory = ref('');
      const filteredProducts = ref([]);
  
      const fetchProducts = async () => {
        const { data } = await axios.get('https://api.takeit.ciph3r.co/products');
        products.value = data;
        filteredProducts.value = data;
      };
  
      const fetchCategories = async () => {
        const { data } = await axios.get('https://api.takeit.ciph3r.co/categories');
        categories.value = data;
      };
  
      const filterProducts = () => {
        filteredProducts.value = products.value.filter(product => {
          const matchesName = product.name.toLowerCase().includes(search.value.toLowerCase());
          const matchesCategory = !selectedCategory.value || product.category === selectedCategory.value;
          return matchesName && matchesCategory;
        });
      };
  
      const addToCart = (product: any) => {
        console.log('Add to cart:', product);
      };
  
      fetchProducts();
      fetchCategories();
  
      return {
        products,
        categories,
        search,
        selectedCategory,
        filteredProducts,
        filterProducts,
        addToCart,
      };
    },
  });
  </script>
  
  <style scoped>
  .v-container {
    margin-top: 20px;
  }
  </style>
  