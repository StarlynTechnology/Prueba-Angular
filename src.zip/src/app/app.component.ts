import { Component, OnInit, ViewChild, AfterViewInit, ElementRef  } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddEditEmpComponent } from './add-edit-emp/add-edit-emp.component';
import { ServiceService } from './shared/service.service';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatSort, MatSortModule} from '@angular/material/sort';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app1';

  displayedColumns: string[] = [
    'titulo', 'autor', 'fecha', 'numeroPage', 'ISBN', 'Stock', 'action'
  ];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild('chart') chart!: ElementRef<HTMLCanvasElement>;


  constructor(private dialog:MatDialog, private service:ServiceService){}
  ngOnInit(): void {
    this.getLibrosList();
  }

  openAddEditEmpForm(){
   const dialogRef = this.dialog.open(AddEditEmpComponent);
   dialogRef.afterClosed().subscribe({
    next:(val)=>{
      if(val){
        this.getLibrosList();
      }
    }
   })
  }

  ngAfterViewInit() {
    if (this.chart && this.chart.nativeElement) {
      const canvas: HTMLCanvasElement = this.chart.nativeElement;
      const ctx = canvas.getContext('2d');

      if (ctx) {
        const labels = this.dataSource.data.map(book => book.titulo);
        const data = this.dataSource.data.map(book => book.Stock);

        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: labels,
            datasets: [{
              label: 'Libros más vendidos',
              data: data,
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
      }
    }
  }


  getLibrosList(){
    this.service.getAllLibros().subscribe({
      next: (res) => {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator
      },
      error:(err)=>{
        alert(err)
      }
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteLibro(id:number){
    this.service.deleteLibro(id).subscribe({
      next:(res)=>{
        alert('Eliminar Libro')
        this.getLibrosList();
      },
      error: console.log

    })
  }
}
