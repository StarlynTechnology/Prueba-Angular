import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServiceService } from '../shared/service.service';
import { DialogRef } from '@angular/cdk/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-add-edit-emp',
  templateUrl: './add-edit-emp.component.html',
  styleUrls: ['./add-edit-emp.component.css'],
})
export class AddEditEmpComponent implements OnInit {
  LibroForm: FormGroup;

  constructor(private fb: FormBuilder, private service:ServiceService,
    private dialogref:DialogRef<AddEditEmpComponent>, @Inject (MAT_DIALOG_DATA) private data:any) {
    this.LibroForm = this.fb.group({
      titulo: '',
      autor: '',
      fecha: '',
      numeroPage: '',
      ISBN: '',
      Stock: '',
    });
  }

  ngOnInit(): void {
    this.LibroForm.patchValue(this.data)
  }

  onFormSubmit() {
    if (this.LibroForm.valid) {
      // console.warn(this.empForm.value)
      this.service.addLibro(this.LibroForm.value).subscribe({
        next: (val:any)=>{
          alert('Libro Agregado correctamente')
          this.dialogref.close()
        },
        error: (err:any)=>{
          alert(err);
        }
      })
    }
  }
}
